# InternAfrica

## Sample screenshot

![Sample screenshot](/src/public/images/screenshot.png "Home page screenshot")

## Technologies used

- HTML
- CSS
- Javascript
- MongoDB

## Libraries and APIs used

- DOM
- Google Fonts Library
- fontawesome Icons
- Express
- mongoose

## Features buit

- Implimented dynamic search bar on home page
- Realtime internships fetched from MongoDB
- Filters functionality for internships page
- Signup/Login functionality by using MongoDB
- Dynamic "View details" page for each internship

## Team Members

- Team Youth Employment

## How to use our app?

- Install git on your machine
- Clone our repository by running the command `git clone https://github.com/SrikanthReddyBV/Internshala.git`
- Change directory to Internshala by running `cd Internshala`
- And then run following two commands
- `npm install`
- `npm start`
- Open your browser and go to `http://localhost:2222/pages/index.ejs`
