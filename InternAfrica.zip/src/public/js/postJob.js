// const User = require("../../models/user.model");

var signup = document.getElementById("submitButton");
signup.addEventListener("click", initiate);

async function initiateSignup() {
  if (
    email.value == "" ||
    password.value == "" ||
    firstname.value == "" ||
    lastname.value == ""
  ) {
    alert("Enter all fields");
    email.value = "";
    password.value = "";
    firstname.value = "";
    lastname.value = "";
  } else {
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let firstname = document.getElementById("firstname").value;
    let lastname = document.getElementById("lastname").value;

    let inputData = {
      firstname,
      lastname,
      password,
      email,
    };
    let isExist = false;
    let res = await fetch("http://localhost:2222/users");
    let registeredUsers = await res.json();

    registeredUsers.forEach((usr) => {
      if (usr.email == inputData.email) {
        isExist = true;
        alert("Email already exists! Please Login");
        window.location.href = "students_log.ejs";
      }
    });

    if (!isExist) {
      let res = await fetch("http://localhost:2222/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(inputData),
      });

      let usr = await res.json();
      console.log(usr);
      alert("Signup Success! Please login");
      window.location.href = "students_log.ejs";
    }
  }
  
}
